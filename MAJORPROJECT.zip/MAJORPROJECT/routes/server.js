const express = require("express");
const app = express();
const listings = require("./listing.js")
const reviews = require("./review.js")









// Root Route
app.get("/", (req, res) => {
    res.send("Hi, I am root");
});

app.use("/listings",listings);
app.use("/reviews", reviews)

app.listen(4000, () => {
    console.log("App is listening on port 4000");
})
