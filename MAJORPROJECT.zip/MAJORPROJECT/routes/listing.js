const wrapAsync = require("../utils/wrapAsync.js");
const ExpressError = require("../utils/ExpressError.js")
const {listingSchema, reviewSchema} = require("../schema.js")
const Listing = require("../models/listing.js");
const { Router } = require("express");
const express = require("express");
const router = express.Router({ mergeParams: true });
const validateListing = (req,res,next) => {
    let {error} = listingSchema.validate(req.body);
    if(error) {
        let errMsg = error.details.map((el)=> 
            el.message).join(",");
        throw new ExpressError(400,errMsg);
    }else {
        next();
    }
};





//create route


router.post(
    "/",
    validateListing,
    async (req, res) => {
      console.log(req.body); // should log: { listing: { title: ..., price: ..., etc. } }
      await Listing.create(req.body.listing);
      res.redirect("/listings");
    }
  );
  

//router.post(
    //"/",
   // validateListing,
   // async(req,res) => {
   // console.log(req.body);
   // await Listing.insertMany({ ...req.body });
  //  res.redirect("/listings");
   

    
//});


// Edit Route 

router.get('/:id/edit', async (req, res) => {
    let {id} = req.params;
    const listing = await Listing.findById(id);
    res.render('listings/edit.ejs', {listing: listing});
})

    

// Index Route
router.get("/", wrapAsync (async (req, res) => {
    const allListings = await Listing.find({});
    console.log(allListings);
    res.render("listings/index.ejs", { allListings });
}));

// New Listing Form Route
router.get("/new", (req, res) => {
    res.render("listings/new.ejs");
});


//update route
router.put('/:id',
    validateListing,
     async (req, res) => {
    const { id } = req.params;
    const listing = await Listing.findByIdAndUpdate(id, req.body.listing);
    res.redirect(`/listings/${listing._id}`);
});

// Show Route
router.get('/:id', async (req, res) => {
    // console.log(req.params); // Debugging line
    const { id } = req.params;
    const listing = await Listing.findById(id).populate("reviews");
    if (!listing) {
        return res.status(404).render('error', { message: "Listing not found" });
    }
    res.render('listings/show', { listing });
});

//Delete route 
router.delete(
    "/:id",
    async (req, res) => {
      const { id } = req.params;
      const deletedListing = await  Listing.findByIdAndDelete(id);
      console.log(deletedListing);
      res.redirect("/listings");
});

module.exports = router;
